# AA YouTube Player (Android Auto Project)

A complete Kotlin Android Studio project with a pre-configured GitHub Actions workflow (`.github/workflows/build-apk.yml`) to compile `app-debug.apk` in the cloud.

## One-Step Cloud Build via GitHub

1. Extract this ZIP archive.
2. Create a new **Public** repository on GitHub.
3. On your new repository page, click **uploading an existing file**, select all files **inside** the `AAYouTubePlayer` folder (including the `.github` folder, `app`, `gradle`, `build.gradle.kts`, `settings.gradle.kts`, etc.), and click **Commit changes**.
4. Open the **Actions** tab at the top of your repository, wait ~2 minutes for **Build Debug APK** to finish, and download **`AAYouTubePlayer-debug`** from the **Artifacts** section.
